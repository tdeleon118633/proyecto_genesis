CREATE DATABASE db_arch_ge


IF OBJECT_ID (N'dbo.usuarios') IS NOT NULL
	DROP TABLE dbo.usuarios
GO

CREATE TABLE dbo.usuarios
	(
	  id               INT IDENTITY NOT NULL
	, apellido_paterno VARCHAR (20) NOT NULL
	, apellido_materno NCHAR (20) NOT NULL
	, nombre           NCHAR (50) NOT NULL
	, correo           NCHAR (20) NOT NULL
	, username         NCHAR (20) NOT NULL
	, password         NCHAR (50) NOT NULL
	, PRIMARY KEY (id)
	)
GO


INSERT INTO dbo.usuarios
	(
	apellido_paterno
	, apellido_materno
	, nombre
	, correo
	, username
	, password
	)
VALUES
	(
	'Tito'
	, 'De Leon'
	, 'Tito De Leon'
	, 'tdeleon@gmail.com'
	, 'tdeleon'
	, '098f6bcd4621d373cade4e832627b4f6'
	)
GO

INSERT INTO dbo.usuarios
	(
	apellido_paterno
	, apellido_materno
	, nombre
	, correo
	, username
	, password
	)
VALUES
	(
	'Contreras'
	, 'Gracia'
	, 'Yeimi mileni'
	, 'tmileni@gmail.com'
	, 'ymileni'
	, '098f6bcd4621d373cade4e832627b4f6'
	)
GO

INSERT INTO dbo.usuarios
	(
	apellido_paterno
	, apellido_materno
	, nombre
	, correo
	, username
	, password
	)
VALUES
	(
	'trigueños'
	, 'Arriaga'
	, 'Abner Fernando'
	, 'afernando@gmail.com'
	, 'afernando'
	, '098f6bcd4621d373cade4e832627b4f6'
	)
GO



IF OBJECT_ID (N'dbo.archivos') IS NOT NULL
	DROP TABLE dbo.archivos
GO

CREATE TABLE dbo.archivos
	(
	  id         INT IDENTITY NOT NULL
	, id_usuario INT NULL
	, nombre     VARCHAR (200) NULL
	, extencion  VARCHAR (200) NULL
	, tamanio    FLOAT NULL
	, ubicacion  TEXT NULL
	, CONSTRAINT FK_UsuariosId FOREIGN KEY (id_usuario) REFERENCES dbo.usuarios (id)
	)
GO

