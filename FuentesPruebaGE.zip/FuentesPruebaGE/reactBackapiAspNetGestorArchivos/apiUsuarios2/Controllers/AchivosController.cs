﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using apiUsuarios2.Context;  //importancion de context
using apiUsuarios2.Models; //modelo archivos
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace apiUsuarios2.Controllers
{
    [Route("api/archivos")]
    [ApiController]
    //[ApiController]
    //[Route("[controller]")]
    public class AchivosController : Controller
    {
        //SE INICIA CONTEXT DETRO DE EL CONTROLLADOR apiUsuarios2.Context;
        //public readonly AppDbContext context
        private readonly AppDbContext context;

        //instanciamos al context
        public AchivosController(AppDbContext context)
        {
            this.context = context;
        }

        // GET: api/<controller>
        [HttpGet]
        public ActionResult Get()
        //public async Task<ActionResult<IEnumerable<Archivos>>> Getarchivos()
        // public async Task<ActionResult<IEnumerable<Archivo>>> GetAchivos()
        {
            try
            {
                //OBTENEMOS TODO LO QUE ESTA INSERTADO EN LA TABLA ARCHIVOS.
                return Ok(context.archivos.ToList());
                //  return await _context.archivos.ToListAsync();
            }
            catch (Exception EX)
            {
                //MANEJO DE ERRORES
                return BadRequest(EX.Message);
            }
        }

        [HttpGet("{id}")]
        public ActionResult Get(int id)
        {
            try
            {
                //var gestor = context.archivos.FindAsync(id);
                var gestor = context.archivos.Where(archivo => archivo.id_usuario.Equals(id)).ToList();
                //var usuarios = _context.usuarios.Where(usuario => usuario.username.Equals(usr) && usuario.password.Equals(pass)).ToList();

                return Ok(gestor);
            }
            catch(Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        //LIBRERIA  Microsoft.AspNetCore.Mvc; PARA IFormFile
        [HttpPost]
        public ActionResult PostAchivos([FromForm]List<IFormFile> files,int id_usu)
        // public async Task<ActionResult<Usuarios>> PostUsuarios(Usuarios usuarios)
        //public async Task<ActionResult<Archivos>> PostAchivos([FromForm]List<IFormFile> files)
        {
            //IMPORTAMOS EL MODELO apiUsuarios2.Models; PARA Archivo
            List<Archivos> archivos = new List<Archivos>();

            //MENEJO DE ERRORES
            try
            {
                if (files.Count > 0)
                {
                    foreach (var file in files)
                    {
                        //ESTABLECEMOS RUTA QUITANDO AGREGANDO DOBLE DIAGONAL MAS NOMBRE DE ARVHIVO
                        var filePath = "C:\\reactBackapiAspNetGestorArchivos\\apiUsuarios2\\Archivos\\" + file.FileName;
                        //GUARDAMOS ARCHIVO EN LA CARPETA
                        using (var stream = System.IO.File.Create(filePath)) {
                            file.CopyToAsync(stream);
                        }
                        double tamanio = file.Length;       //OBTENEMOS EL TAMAÑO DEL ARCHIVO EN BYTE
                        tamanio = tamanio / 1000000;       //LO PASAMOS A MEGA BYTE
                        tamanio = Math.Round(tamanio, 2);   //REDONDEAMOS A DOS DECIMALES
                        Archivos archivo_usuario = new Archivos(); //Establecemos propiedades en el modelo
                        
                        
                        archivo_usuario.nombre = Path.GetFileNameWithoutExtension(file.FileName);
                        archivo_usuario.extencion = Path.GetExtension(file.FileName).Substring(1);  //1 Obtenemos la extencion de el archivo y quitamos el punto que esta en el inicio 2 - agregamos System.IO; para Path
                        archivo_usuario.tamanio = tamanio;
                        archivo_usuario.ubicacion = filePath;
                        archivo_usuario.id_usuario = id_usu;
                        archivos.Add(archivo_usuario); //SE AGREGA A LA LISTA PARA LUEGO RETORNARLO AL USUARIO
                    }
                    /* INSERCION EN LA BASE DE DATOS */
                    context.archivos.AddRange(archivos);
                    context.SaveChanges();//Guarda

                   // context.usuarios.Add(archivos);
                    //await context.SaveChangesAsync();


                }

            } catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }

            return Ok(archivos); //RETORNAMOS ARCHIVOS GUARDADOS
        }

    }
}
